﻿using System;
using System.Data.SqlClient;

namespace UnitTests
{
    public class UnitTest
    {
        public int Administration(int admin)
        {
            string connectionString2 = @"Data Source=DESKTOP-U3T0DTQ\MSSQLSERVER01;Initial Catalog=OOOMuscle;User Id=sa;Password=qwerty";
            SqlConnection conn2 = new SqlConnection(connectionString2);
            conn2.Open();
            SqlCommand cmd2 = new SqlCommand("Select RoleID from [User] WHERE [Login] = 'Petrov123'", conn2);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                admin = Convert.ToInt32(dr2["RoleID"]);
                return admin;
            }
            conn2.Close();
            return admin;
        }

        public int Menedger(int meneg)
        {
            string connectionString2 = @"Data Source=DESKTOP-U3T0DTQ\MSSQLSERVER01;Initial Catalog=OOOMuscle;User Id=sa;Password=qwerty";
            SqlConnection conn2 = new SqlConnection(connectionString2);
            conn2.Open();
            SqlCommand cmd2 = new SqlCommand("Select RoleID from [User] WHERE [Login] = 'Shishkova'", conn2);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                meneg = Convert.ToInt32(dr2["RoleID"]);
                return meneg;
            }
            conn2.Close();
            return meneg;
        }

        public int Klient(int klient)
        {
            string connectionString2 = @"Data Source=DESKTOP-U3T0DTQ\MSSQLSERVER01;Initial Catalog=OOOMuscle;User Id=sa;Password=qwerty";
            SqlConnection conn2 = new SqlConnection(connectionString2);
            conn2.Open();
            SqlCommand cmd2 = new SqlCommand("Select RoleID from [User] WHERE [Login] = 'Maslo'", conn2);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                klient = Convert.ToInt32(dr2["RoleID"]);
                return klient;
            }
            conn2.Close();
            return klient;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
