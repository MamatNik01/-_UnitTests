﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOOMuscle
{
    public class Helper
    {
        public static DBMuscle.OOOMuscleEntities1 db;
        public static DBMuscle.User user;
        public static DBMuscle.Product product;
        public static DBMuscle.Order order;
        public static DBMuscle.Sostav sostav;
    }
}
