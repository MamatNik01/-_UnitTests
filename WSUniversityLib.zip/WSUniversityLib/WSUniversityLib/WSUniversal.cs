﻿using System;

namespace WSUniversalLib
{
    public class UniversalLib
    {
        public int Universal_brak(float width, float length, int count, float productType, float materialType) // работает не всегда
        {
            int a = 100;
            if (productType > 0 || materialType > 0 || count > 0 || width > 0 || length > 0)
            {
                return Convert.ToInt32((((width * length * count * productType) * (a + materialType) / a) + 1)); // добавить 1 при округлении
            }
            else throw new Exception("-1");
        }

        public int Universal_without(float width, float length, int count, float productType)
        {
            if (productType > 0 || count > 0 || width > 0 || length > 0)
            {
                return Convert.ToInt32(width * length * count * productType);
            }
            else throw new Exception("-1");
        }
    }
}

